﻿using System;

namespace DayClientML2.Utility
{
	// Token: 0x02000053 RID: 83
	public enum MenuType
	{
		// Token: 0x040001BF RID: 447
		UserInfo,
		// Token: 0x040001C0 RID: 448
		AvatarMenu,
		// Token: 0x040001C1 RID: 449
		SettingsMenu,
		// Token: 0x040001C2 RID: 450
		SocialMenu,
		// Token: 0x040001C3 RID: 451
		WorldMenu,
		// Token: 0x040001C4 RID: 452
		WorldInfo
	}
}
