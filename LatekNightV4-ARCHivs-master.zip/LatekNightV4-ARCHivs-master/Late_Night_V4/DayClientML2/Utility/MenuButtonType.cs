﻿using System;

namespace DayClientML2.Utility
{
	// Token: 0x0200004F RID: 79
	internal enum MenuButtonType
	{
		// Token: 0x040001B3 RID: 435
		PlaylistButton,
		// Token: 0x040001B4 RID: 436
		AvatarFavButton,
		// Token: 0x040001B5 RID: 437
		HeaderButton
	}
}
