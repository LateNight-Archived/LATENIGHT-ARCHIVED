﻿using System;
using System.Collections.Generic;

namespace XButtonAPI
{
	// Token: 0x02000037 RID: 55
	public static class XButtonAPI
	{
		// Token: 0x0400016D RID: 365
		public static List<QMSingleButton> allSingleButtons = new List<QMSingleButton>();

		// Token: 0x0400016E RID: 366
		public static List<QMEmptyButton> allEmpty = new List<QMEmptyButton>();

		// Token: 0x0400016F RID: 367
		public static List<QMSingleToggleButton> allSingleToggleButtons = new List<QMSingleToggleButton>();

		// Token: 0x04000170 RID: 368
		public static List<QMToggleButton> allToggleButtons = new List<QMToggleButton>();

		// Token: 0x04000171 RID: 369
		public static List<QMNestedButton> allNestedButtons = new List<QMNestedButton>();

		// Token: 0x04000172 RID: 370
		public static List<QMLabel> allLabelsButton = new List<QMLabel>();

		// Token: 0x04000173 RID: 371
		public static List<QMSlider> allSliders = new List<QMSlider>();

		// Token: 0x04000174 RID: 372
		public static List<QMEmptyWing> allEmptyWings = new List<QMEmptyWing>();

		// Token: 0x04000175 RID: 373
		public static List<QMSingleWing> allSingleWings = new List<QMSingleWing>();

		// Token: 0x04000176 RID: 374
		public static List<QMToggleWing> allToggleWings = new List<QMToggleWing>();

		// Token: 0x04000177 RID: 375
		public static List<QMNestedWing> allnestedWings = new List<QMNestedWing>();

		// Token: 0x04000178 RID: 376
		public static List<QMCategoryPage> allcategorypages = new List<QMCategoryPage>();

		// Token: 0x04000179 RID: 377
		public static List<QMTabMenu> allTabsButton = new List<QMTabMenu>();
	}
}
