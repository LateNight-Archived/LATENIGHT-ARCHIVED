﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using Late_Night_V3;
using MelonLoader;

[assembly: AssemblyVersion("4.1.0.0")]
[assembly: AssemblyTitle("Late_Night_V4")]
[assembly: AssemblyDescription("VRC HAX")]
[assembly: AssemblyConfiguration("Lucy")]
[assembly: AssemblyCompany("Late_Night")]
[assembly: AssemblyProduct("Late_Night_V4")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: MelonInfo(typeof(Late_Night), "Late_Night_V4", "4.1.0.0", "Lady Lucy#7443", "")]
[assembly: MelonGame("VRChat", "VRChat")]
[assembly: ComVisible(false)]
[assembly: Guid("ba18e3ca-774d-410f-9564-9638e916a732")]
[assembly: AssemblyFileVersion("4.1.0.0")]
