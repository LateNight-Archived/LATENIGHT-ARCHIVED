﻿using System;
using System.Collections.Generic;

namespace Late_Night_V3_AvatarObject
{
	// Token: 0x02000036 RID: 54
	public class serverAvatarObject
	{
		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060001EF RID: 495 RVA: 0x000140DB File Offset: 0x000122DB
		// (set) Token: 0x060001F0 RID: 496 RVA: 0x000140E3 File Offset: 0x000122E3
		public List<AvatarObject> Avis { get; set; }
	}
}
