# LatekNightV4-ARCHivs
Last version of LatenightV4 release


- LateNight was free and publically available to anyone who wished to use it

- No attempts were made to protect the software in any form.

- Software was not stolen, nor were any false claims of ownership of said software were made,

- The public software was simply uploaded to this repository for archival purposes, due to the nature of the software being Abandoned by the developers.

- This was made in a public statement by the developers describing that there was no longer going to be support or further development on the software and the developers were leaving the project.


> Thus, this repo will remain active
